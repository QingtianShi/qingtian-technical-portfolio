# Lab 5: Build and Query the Peer Tutoring Hub Database

**Name:** Qingtian Shi  
**University ID:** u1377576

## Execution and Codespaces

The SQL was tested locally and then successfully run in GitHub Codespaces. The screenshot below shows the JOIN result, Jordan's request before and after revision, Avery's Cancelled status, the test request before deletion, a zero count after deletion, the three remaining requests, both table names, and the schemas.

![Codespaces SQL results and table schemas](lab5-codespaces-results.png)

Codespaces project link shown in the browser: [Open Codespaces](https://zany-zebra-p77vwv99w59j279j4.github.dev/).

Instructor access to the project link has not been verified.

The pasted output in Parts 1–5 below comes from local verification. The screenshot above provides the Codespaces evidence. SQLite generates timestamps in UTC, so `created_at` values differ between runs. The appointment dates and CRUD results match.

The script has already run in Codespaces; do not run it again against the populated database. No PHP application files were changed for this work.

## Part 1: Create the database tables

The following output shows both table names and their schemas.

```text
students           tutoring_requests
CREATE TABLE students (
  student_id INTEGER PRIMARY KEY,
  student_name TEXT NOT NULL,
  student_email TEXT NOT NULL UNIQUE
);
CREATE TABLE tutoring_requests (
  request_id INTEGER PRIMARY KEY,
  student_id INTEGER NOT NULL,
  course TEXT NOT NULL,
  topic TEXT NOT NULL,
  preferred_date TEXT NOT NULL,
  preferred_time TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Open',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(student_id)
);
```

The primary key in `students` is `student_id`. The primary key in `tutoring_requests` is `request_id`.

The foreign key is `tutoring_requests.student_id`, which references `students.student_id`. It represents a one-to-many relationship: one student can submit multiple tutoring requests, and each request belongs to one student. `PRAGMA foreign_keys = ON` enables SQLite to enforce this relationship for the connection.

The `UNIQUE` constraint on `student_email` prevents two student rows from using the same email address.

## Part 2: Insert students and tutoring requests

These are the INSERT statements used:

```sql
-- Part 2: Insert students and tutoring requests
INSERT INTO students (student_id, student_name, student_email) VALUES
  (1, 'Jordan Lee', 'jordan.lee@example.edu'),
  (2, 'Avery Patel', 'avery.patel@example.edu');
INSERT INTO tutoring_requests
  (request_id, student_id, course, topic, preferred_date, preferred_time)
VALUES
  (1, 1, 'IS 6465', 'Forms', '2026-11-10', '14:00'),
  (2, 1, 'IS 6465', 'SQL SELECT', '2026-11-12', '15:00'),
  (3, 2, 'IS 6465', 'SQLite CRUD', '2026-11-13', '16:00');
```

The following SELECT output shows both students and the three original requests.

```text
student_id  student_name  student_email          
----------  ------------  -----------------------
1           Jordan Lee    jordan.lee@example.edu 
2           Avery Patel   avery.patel@example.edu
request_id  student_id  course   topic        preferred_date  preferred_time  status  created_at         
----------  ----------  -------  -----------  --------------  --------------  ------  -------------------
1           1           IS 6465  Forms        2026-11-10      14:00           Open    2026-11-07 01:24:02
2           1           IS 6465  SQL SELECT   2026-11-12      15:00           Open    2026-11-07 01:24:02
3           2           IS 6465  SQLite CRUD  2026-11-13      16:00           Open    2026-11-07 01:24:02
```

Jordan has one student row because the student information should be stored once. Jordan has two request rows because each tutoring appointment is a separate request. Both requests use `student_id = 1` to connect to Jordan's student row.

## Part 3: Read the stored data

All five required queries are included in `tutoring.sql`. The JOIN query is:

```sql
SELECT r.request_id, s.student_name, s.student_email,
       r.course, r.topic, r.preferred_date, r.preferred_time, r.status
FROM tutoring_requests AS r
JOIN students AS s ON r.student_id = s.student_id
ORDER BY r.preferred_date, r.request_id;
```

Its output before the updates is:

```text
request_id  student_name  student_email            course   topic        preferred_date  preferred_time  status
----------  ------------  -----------------------  -------  -----------  --------------  --------------  ------
1           Jordan Lee    jordan.lee@example.edu   IS 6465  Forms        2026-11-10      14:00           Open  
2           Jordan Lee    jordan.lee@example.edu   IS 6465  SQL SELECT   2026-11-12      15:00           Open  
3           Avery Patel   avery.patel@example.edu  IS 6465  SQLite CRUD  2026-11-13      16:00           Open  
```

The JOIN condition connects the `student_id` in each request to the matching `student_id` in the students table, so the result includes the student's name and email.

JOIN combines related rows from tables, while WHERE filters rows according to a condition. They can be used together in the same query.

The application should retrieve one request by `request_id` because the primary key uniquely identifies it. A topic is not unique, so searching by topic alone could return several requests.

## Part 4: Update one request

The two UPDATE statements used are:

```sql
UPDATE tutoring_requests
SET topic = 'Forms and validation',
    preferred_date = '2026-11-11',
    preferred_time = '14:30'
WHERE request_id = 1;

UPDATE tutoring_requests
SET status = 'Cancelled'
WHERE request_id = 3;
```

The output below shows request 1 before the revision, request 1 after the revision, and Avery's request 3 with its Cancelled status, in that order.

```text
request_id  student_id  course   topic  preferred_date  preferred_time  status  created_at         
----------  ----------  -------  -----  --------------  --------------  ------  -------------------
1           1           IS 6465  Forms  2026-11-10      14:00           Open    2026-11-07 01:24:02
request_id  student_id  course   topic                 preferred_date  preferred_time  status  created_at         
----------  ----------  -------  --------------------  --------------  --------------  ------  -------------------
1           1           IS 6465  Forms and validation  2026-11-11      14:30           Open    2026-11-07 01:24:02
request_id  student_id  course   topic        preferred_date  preferred_time  status     created_at         
----------  ----------  -------  -----------  --------------  --------------  ---------  -------------------
3           2           IS 6465  SQLite CRUD  2026-11-13      16:00           Cancelled  2026-11-07 01:24:02
```

A specific WHERE clause is essential because it limits the update to the intended request. Without WHERE, the update would change every row in the table.

Using a Cancelled status preserves the real request's history and its connection to the student. The application can distinguish a cancelled appointment from a request that never existed.

## Part 5: Delete one test request

The test INSERT and targeted DELETE statements are:

```sql
INSERT INTO tutoring_requests
  (request_id, student_id, course, topic, preferred_date, preferred_time)
VALUES (4, 1, 'IS 6465', 'Delete Practice', '2026-11-14', '10:00');

DELETE FROM tutoring_requests WHERE request_id = 4;
```

The following output first shows the test request before deletion. The count of zero verifies that request 4 was removed, and the final SELECT shows that requests 1, 2, and 3 remain.

```text
request_id  student_id  course   topic            preferred_date  preferred_time  status  created_at         
----------  ----------  -------  ---------------  --------------  --------------  ------  -------------------
4           1           IS 6465  Delete Practice  2026-11-14      10:00           Open    2026-11-07 01:24:02
test_requests_remaining
-----------------------
0                      
request_id  student_id  course   topic                 preferred_date  preferred_time  status     created_at         
----------  ----------  -------  --------------------  --------------  --------------  ---------  -------------------
1           1           IS 6465  Forms and validation  2026-11-11      14:30           Open       2026-11-07 01:24:02
2           1           IS 6465  SQL SELECT            2026-11-12      15:00           Open       2026-11-07 01:24:02
3           2           IS 6465  SQLite CRUD           2026-11-13      16:00           Cancelled  2026-11-07 01:24:02
```

A WHERE clause is essential in DELETE because it identifies which record to remove. Without WHERE, DELETE would remove all rows from the table.

## Part 6: Reflect on the CRUD workflow

| CRUD action | SQL statement used in this lab | Peer Tutoring Hub example |
| --- | --- | --- |
| Create | `INSERT INTO` | Add Jordan and Avery and create their tutoring requests. |
| Read | `SELECT`, including `WHERE` and `JOIN` | List requests with student names and email addresses. |
| Update | `UPDATE ... SET ... WHERE` | Revise Jordan's appointment and cancel Avery's request. |
| Delete | `DELETE FROM ... WHERE` | Remove only the Delete Practice test request. |

`CREATE TABLE` defines the database structure; the Create operation in CRUD refers to inserting records.

1. The database preserves the connection by storing the student's primary key in each request's `student_id` foreign key. With foreign key enforcement enabled, a request cannot reference a student who does not exist.
2. The `UNIQUE` constraint on `students.student_email` prevents duplicate email addresses, and `NOT NULL` requires an email value.
3. An UPDATE without WHERE could change every request, and a DELETE without WHERE could remove every request from the table.
4. PHP should use prepared statements and bind form values as parameters so input is treated as data. This helps prevent SQL injection and avoids errors when values contain quotation marks or other special characters.
