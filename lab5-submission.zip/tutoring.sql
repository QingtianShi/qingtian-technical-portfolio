-- Lab 5: Peer Tutoring Hub
-- Qingtian Shi | u1377576
-- Run once against a new, empty tutoring.db database.

-- Part 1: Create tables
PRAGMA foreign_keys = ON;
CREATE TABLE students (
  student_id INTEGER PRIMARY KEY,
  student_name TEXT NOT NULL,
  student_email TEXT NOT NULL UNIQUE
);
CREATE TABLE tutoring_requests (
  request_id INTEGER PRIMARY KEY,
  student_id INTEGER NOT NULL,
  course TEXT NOT NULL,
  topic TEXT NOT NULL,
  preferred_date TEXT NOT NULL,
  preferred_time TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Open',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(student_id)
);

-- Part 2: Insert students and tutoring requests
INSERT INTO students (student_id, student_name, student_email) VALUES
  (1, 'Jordan Lee', 'jordan.lee@example.edu'),
  (2, 'Avery Patel', 'avery.patel@example.edu');
INSERT INTO tutoring_requests
  (request_id, student_id, course, topic, preferred_date, preferred_time)
VALUES
  (1, 1, 'IS 6465', 'Forms', '2026-11-10', '14:00'),
  (2, 1, 'IS 6465', 'SQL SELECT', '2026-11-12', '15:00'),
  (3, 2, 'IS 6465', 'SQLite CRUD', '2026-11-13', '16:00');
SELECT * FROM students;
SELECT * FROM tutoring_requests;

-- Part 3: Read the stored data
SELECT * FROM students;
SELECT * FROM tutoring_requests;
SELECT * FROM tutoring_requests WHERE status = 'Open';
SELECT * FROM tutoring_requests WHERE request_id = 2;
SELECT r.request_id, s.student_name, s.student_email,
       r.course, r.topic, r.preferred_date, r.preferred_time, r.status
FROM tutoring_requests AS r
JOIN students AS s ON r.student_id = s.student_id
ORDER BY r.preferred_date, r.request_id;

-- Part 4: Update one request and cancel another
-- Before the revision:
SELECT * FROM tutoring_requests WHERE request_id = 1;
UPDATE tutoring_requests
SET topic = 'Forms and validation',
    preferred_date = '2026-11-11',
    preferred_time = '14:30'
WHERE request_id = 1;
-- After the revision:
SELECT * FROM tutoring_requests WHERE request_id = 1;
UPDATE tutoring_requests
SET status = 'Cancelled'
WHERE request_id = 3;
SELECT * FROM tutoring_requests WHERE request_id = 3;

-- Part 5: Delete one test request
INSERT INTO tutoring_requests
  (request_id, student_id, course, topic, preferred_date, preferred_time)
VALUES (4, 1, 'IS 6465', 'Delete Practice', '2026-11-14', '10:00');
SELECT * FROM tutoring_requests WHERE request_id = 4;
DELETE FROM tutoring_requests WHERE request_id = 4;
SELECT COUNT(*) AS test_requests_remaining
FROM tutoring_requests WHERE request_id = 4;
SELECT * FROM tutoring_requests ORDER BY request_id;

-- Part 6: CRUD reflections are documented in lab5-notes.md.
