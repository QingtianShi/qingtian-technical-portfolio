# Qingtian Shi — Technical Portfolio

Welcome to my technical portfolio. This repository showcases selected academic and professional projects in data analytics, database design, systems analysis, supply chain, and business intelligence.

I am a Master of Science in Information Systems student at the University of Utah with a background in Operations and Supply Chain. My work focuses on using data, process improvement, and information systems to solve practical business problems.

## Technical Skills

- **Programming & Analytics:** Python, R, SQL, Jupyter Notebook, R Markdown
- **Data & Visualization:** Pandas, scikit-learn, ggplot2, Excel, Tableau/Power BI
- **Database & Systems Design:** PostgreSQL, ERD, DFD, CRUD Matrix, Lucidchart
- **Business & Operations:** Supply Chain Analytics, Lean Six Sigma, Process Improvement
- **Platforms & Tools:** Databricks, GitHub, Git, Microsoft Office

## Featured Projects

### 1. SAH EEG Monitoring and Alert System
**Area:** Systems Analysis, Healthcare Information Systems, Database Design

Designed a proposed information system to support continuous EEG monitoring for patients at risk of vasospasm after subarachnoid hemorrhage. The project includes logical and physical ERDs, DFDs, system architecture, CRUD analysis, interface mockups, and non-functional requirements.

**Key contributions**
- Modeled neurologist and EEG technician workflows.
- Designed EEG flowsheet, EEG reading, assignment, alert, and clinical order data structures.
- Evaluated cloud deployment, security, scalability, and clinical usability requirements.

**Tools:** Lucidchart, SQL concepts, systems analysis and design

[View project](projects/sah-eeg-monitoring-system/)

---

### 2. Healthcare Insurance Cost Prediction
**Area:** Predictive Analytics, Regression

Analyzed healthcare insurance data to identify factors associated with medical expenses and developed regression-based prediction models.

**Key contributions**
- Cleaned and prepared continuous and categorical variables.
- Interpreted coefficients and statistical significance.
- Evaluated model performance using error metrics such as MAE and RMSE.

**Tools:** R, regression modeling, data visualization

[View project](projects/insurance-cost-prediction/)

---

### 3. Machine Learning Classification and Clustering
**Area:** Data Mining, Machine Learning

Applied decision trees, k-nearest neighbors, support vector machines, artificial neural networks, and k-means clustering to structured datasets.

**Key contributions**
- Compared white-box and black-box models.
- Used cross-validation and classification metrics.
- Interpreted accuracy, precision, recall, and F1 score.
- Evaluated cluster assignments and model limitations.

**Tools:** R, Python, caret, C5.0, scikit-learn

[View project](projects/machine-learning-models/)

---

### 4. Database Design and Advanced SQL
**Area:** Database Management

Designed relational databases and wrote SQL for data definition, joins, aggregation, views, common table expressions, stored procedures, and window functions.

**Key contributions**
- Created logical and physical data models.
- Defined primary keys, foreign keys, and relationship cardinalities.
- Normalized data structures and developed analytical queries.

**Tools:** PostgreSQL, SQL, Lucidchart

[View project](projects/database-design-sql/)

---

### 5. Supply Chain Performance Analysis
**Area:** Operations and Supply Chain Analytics

Analyzed shipment performance during a supply chain internship, including more than 13,000 CPU shipments.

**Key contributions**
- Measured on-time, early, and late shipment performance.
- Identified carriers and routes with elevated delay rates.
- Recommended carrier, scheduling, and follow-up improvements.

**Tools:** Excel, operational analytics, process improvement

[View project](projects/supply-chain-performance/)

---

### 6. Lean Six Sigma Process Improvement
**Area:** Process Improvement, Operations

Redesigned a production workflow using Lean Six Sigma methods to improve throughput, balance work, and reduce operational waste.

**Key contributions**
- Created value stream maps, work balance tables, and standardized work charts.
- Used takt time, control charts, and risk assessment.
- Developed countermeasures and estimated financial impact.

**Tools:** Excel, Lean Six Sigma, process mapping

[View project](projects/lean-six-sigma/)

## Education

**Master of Science in Information Systems**  
University of Utah, David Eccles School of Business

**Bachelor’s Degree in Operations and Supply Chain**

## Professional Interests

- Data Analytics
- Business Intelligence
- Systems Analysis
- Supply Chain and Operations Analytics
- Process Improvement
- Technology Consulting

## Contact

- GitHub: [QingtianShi](https://github.com/QingtianShi)
- LinkedIn: Add your LinkedIn URL here
- Email: Add your professional email here

---

This portfolio is continuously updated as I complete new academic, professional, and personal projects.
